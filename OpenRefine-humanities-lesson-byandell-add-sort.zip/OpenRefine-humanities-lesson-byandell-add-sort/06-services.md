---
layout: lesson
root: .
title: Services in OpenRefine
minutes: .
---

# Learning Objectives

**Optional material, and under development**

* Show call to an API, a web service (JSON example here from a locality georeferencing service)
* If time, show how to parse the JSON returned from the service.


# Lesson

## Call a Service (this example is set up to georeference locality data, but could use any service).

* For this demo, the instructor may find a web service appropriate to demonstrate.

Previous: [Saving and Exporting files and projects](05-save-export.html)  Optional Next: [Other Resources in OpenRefine](07-resources.html)


