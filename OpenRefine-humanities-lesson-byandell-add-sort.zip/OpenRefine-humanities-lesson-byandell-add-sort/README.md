# lesson-template
This is a repository that is a template for lessons

Lesson template is rendered here:

http://datacarpentry.github.io/lesson-template/
