---
layout: lesson
root: .
title: Scripts from OpenRefine
minutes: .
---

# Learning Objectives

* Describe how OpenRefine generates JSON code.
* Demonstrate ability to export JSON code from OpenRefine.
* Save JSON code from an analysis.
* Apply saved JSON code to an analysis.
 

----------------------------------------------------

# Lesson

## Scripts

* Refine saves every change, every edit you make to the dataset in a file you can save on your machine.
* If you had 20 files to clean, and they all had the same type of errors, and all files had the same columns, you could save the script, open a new file to clean, paste in the script and run it. Voila, clean data.

````
  - In the Undo / Redo section, click Extract, save the bits desired using the check boxes. 
  - Copy the code and paste it into a text editor. Save it as a .txt file. 
````

To run these steps on a new dataset, import the new dataset into Refine, open the Extract / Apply section, paste in the .txt file, click Apply.

Previous:  [Examining Numeric Data](03-numbers.html)  Next: [Saving and Exporting files and projects](05-save-export.html)

